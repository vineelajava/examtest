package com.epam.ubs.epammanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpammanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
